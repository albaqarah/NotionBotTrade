# Skill: Scalping Binance USDT-M Perp (Top 10 non-stablecoin)

**Mode:** One-way (per simbol) · Long + Short · Leverage maks 10x  
**Tujuan:** Profit stabil dengan pengaman ketat anti-overtrade + anti-likuidasi.

---

## 1) Tujuan
Menjalankan strategi scalping sistematis di Binance USDT-M perpetual futures dengan:
- Cooldown strict berbasis waktu + kondisi market
- Position sizing dibatasi 10% dari free/available futures margin
- Cek buffer anti-likuidasi wajib
- Eksekusi hybrid: maker dulu, taker hanya jika confidence/edge kuat

---

## 2) Universe Trading
Baseline:
- BTCUSDT
- ETHUSDT
- SOLUSDT
- BNBUSDT
- XRPUSDT
- DOGEUSDT

Opsional jika lolos filter likuiditas:
- ADAUSDT
- TRXUSDT

Exclude stablecoin untuk directional scalping.

---

## 3) Mode Posisi
One-way per simbol:
- FLAT
- LONG
- SHORT

Aturan flip:
1. Tutup posisi lama dulu.
2. Masuk cooldown.
3. Setelah cooldown selesai dan marketOK true, baru boleh buka arah baru.

---

## 4) Free Margin Otomatis
Setiap entry:

```text
freeMarginUSDT = available margin / available balance dari akun futures
entryMargin = 0.10 * freeMarginUSDT
positionNotional = entryMargin * 10
```

Gunakan available/free margin, bukan total wallet balance.

---

## 5) Cooldown Strict
Cooldown selesai hanya jika:
1. Timer cooldown sudah lewat, dan
2. marketOK == true

Jika timer selesai tapi marketOK false:
- extend cooldown 30-60 detik.

Default:
- Setelah TP: BTC/ETH 20s, Alt 30s
- Setelah SL: BTC/ETH 180s, Alt 300s
- Emergency exit: BTC/ETH 5 menit, Alt 15 menit
- 2x SL berturut pada simbol sama: cooldown 10-15 menit

---

## 6) marketOK Baseline
BTC/ETH:
- spreadBps <= 1.5
- depthUsdtTop20 >= 200000
- estimatedSlippageBps <= 2.0
- dataDelayMs <= 250

Alt:
- spreadBps <= 3.0
- depthUsdtTop20 >= 50000
- estimatedSlippageBps <= 5.0
- dataDelayMs <= 250

---

## 7) Stop Loss
SL wajib reduce-only.

LONG:
```text
SL = entry - max(k * microVol, structureStop)
```

SHORT:
```text
SL = entry + max(k * microVol, structureStop)
```

Default k:
- BTC/ETH: 2.0-3.0
- Alt: 2.5-4.0

Anti-likuidasi:
- BTC/ETH: jarak SL ke liquidation >= 1.5%
- Alt: jarak SL ke liquidation >= 3.0%

Jika gagal, skip trade atau kecilkan size.

---

## 8) Larangan
- Jangan martingale.
- Jangan average down.
- Jangan entry jika marketOK false.
- Jangan entry jika SL terlalu dekat liquidation.
- Jangan commit API key ke GitHub.

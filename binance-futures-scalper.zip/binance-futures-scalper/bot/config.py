from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import List

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass


def _bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


def _float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if not raw:
        return default
    return float(raw)


def _int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if not raw:
        return default
    return int(raw)


def _symbols() -> List[str]:
    raw = os.getenv("SYMBOLS", "BTCUSDT,ETHUSDT,SOLUSDT,BNBUSDT,XRPUSDT,DOGEUSDT")
    return [s.strip().upper() for s in raw.split(",") if s.strip()]


@dataclass(frozen=True)
class Settings:
    api_key: str = os.getenv("BINANCE_API_KEY", "")
    api_secret: str = os.getenv("BINANCE_API_SECRET", "")
    dry_run: bool = _bool("DRY_RUN", True)
    use_testnet: bool = _bool("USE_TESTNET", True)
    leverage: int = _int("LEVERAGE", 10)
    entry_margin_pct: float = _float("ENTRY_MARGIN_PCT", 0.10)
    symbols: List[str] = field(default_factory=_symbols)
    loop_seconds: float = _float("LOOP_SECONDS", 5.0)
    log_level: str = os.getenv("LOG_LEVEL", "INFO").upper()

    # Cooldown defaults in seconds
    cd_tp_btc_eth: int = 20
    cd_tp_alt: int = 30
    cd_sl_btc_eth: int = 180
    cd_sl_alt: int = 300
    cd_emergency_btc_eth: int = 300
    cd_emergency_alt: int = 900
    cd_bad_market_extend_btc_eth: int = 30
    cd_bad_market_extend_alt: int = 60

    # marketOK thresholds
    max_spread_bps_btc_eth: float = 1.5
    max_spread_bps_alt: float = 3.0
    min_depth_usdt_top20_btc_eth: float = 200_000
    min_depth_usdt_top20_alt: float = 50_000
    max_slippage_bps_btc_eth: float = 2.0
    max_slippage_bps_alt: float = 5.0
    max_data_delay_ms: int = 250

    # anti-liquidation buffers
    min_sl_to_liq_btc_eth: float = 0.015
    min_sl_to_liq_alt: float = 0.03


def is_btc_eth(symbol: str) -> bool:
    return symbol.upper() in {"BTCUSDT", "ETHUSDT"}

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from .market import MarketSnapshot


@dataclass
class Signal:
    side: Literal["LONG", "SHORT", "NONE"] = "NONE"
    confidence: float = 0.0
    reason: str = "no signal"


class Strategy:
    """Replace this with your real model.

    Suggested future model:
    - LightGBM/XGBoost for short-horizon probability.
    - Output long_confidence and short_confidence.
    - Only return LONG/SHORT when confidence is above threshold.
    """

    def generate(self, snapshot: MarketSnapshot) -> Signal:
        # Safe default: no live signals.
        return Signal(side="NONE", confidence=0.0, reason="placeholder strategy returns no trades")

"""Binance futures scalping bot starter."""
__version__ = '0.1.0'

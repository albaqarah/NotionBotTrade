from __future__ import annotations

from dataclasses import dataclass
from .config import Settings, is_btc_eth


@dataclass
class MarketSnapshot:
    symbol: str
    best_bid: float
    best_ask: float
    depth_usdt_top20: float
    estimated_slippage_bps: float
    data_delay_ms: int = 0
    return_1s: float = 0.0

    @property
    def mid(self) -> float:
        return (self.best_bid + self.best_ask) / 2

    @property
    def spread_bps(self) -> float:
        if self.mid <= 0:
            return 999999
        return (self.best_ask - self.best_bid) / self.mid * 10_000


def market_ok(snapshot: MarketSnapshot, settings: Settings) -> bool:
    btceth = is_btc_eth(snapshot.symbol)

    if snapshot.data_delay_ms > settings.max_data_delay_ms:
        return False

    if btceth:
        if snapshot.spread_bps > settings.max_spread_bps_btc_eth:
            return False
        if snapshot.depth_usdt_top20 < settings.min_depth_usdt_top20_btc_eth:
            return False
        if snapshot.estimated_slippage_bps > settings.max_slippage_bps_btc_eth:
            return False
    else:
        if snapshot.spread_bps > settings.max_spread_bps_alt:
            return False
        if snapshot.depth_usdt_top20 < settings.min_depth_usdt_top20_alt:
            return False
        if snapshot.estimated_slippage_bps > settings.max_slippage_bps_alt:
            return False

    return True

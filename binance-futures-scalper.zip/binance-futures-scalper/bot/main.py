from __future__ import annotations

import time

from .config import Settings
from .cooldown import CooldownManager
from .exchange_binance import BinanceFuturesClient
from .logger import setup_logger
from .market import MarketSnapshot, market_ok
from .risk import calc_entry_from_free_margin
from .strategy import Strategy


def demo_snapshot(symbol: str) -> MarketSnapshot:
    """Placeholder market data. Replace with Binance websocket/orderbook data."""
    price = 100.0
    if symbol.startswith("BTC"):
        price = 65000.0
    elif symbol.startswith("ETH"):
        price = 3500.0
    return MarketSnapshot(
        symbol=symbol,
        best_bid=price * 0.99995,
        best_ask=price * 1.00005,
        depth_usdt_top20=250000 if symbol in {"BTCUSDT", "ETHUSDT"} else 60000,
        estimated_slippage_bps=1.0 if symbol in {"BTCUSDT", "ETHUSDT"} else 3.0,
        data_delay_ms=50,
    )


def main() -> None:
    settings = Settings()
    log = setup_logger(settings)
    client = BinanceFuturesClient(settings)
    cooldown = CooldownManager(settings)
    strategy = Strategy()

    log.info("Starting bot | dry_run=%s | testnet=%s | leverage=%sx", settings.dry_run, settings.use_testnet, settings.leverage)
    log.info("Symbols: %s", ", ".join(settings.symbols))

    for symbol in settings.symbols:
        log.info("Setting leverage %s to %sx", symbol, settings.leverage)
        client.set_leverage(symbol, settings.leverage)

    while True:
        try:
            free_margin = client.get_available_margin_usdt()
            log.info("Available/free futures margin: %.4f USDT", free_margin)

            for symbol in settings.symbols:
                snapshot = demo_snapshot(symbol)
                ok = market_ok(snapshot, settings)

                if not cooldown.can_trade_strict(symbol, ok):
                    st = cooldown.state(symbol)
                    log.info("%s cooldown/no-trade | reason=%s | until=%.0f | marketOK=%s", symbol, st.reason, st.until_ts, ok)
                    continue

                signal = strategy.generate(snapshot)
                if signal.side == "NONE":
                    log.info("%s no signal | %s", symbol, signal.reason)
                    continue

                plan = calc_entry_from_free_margin(symbol, signal.side, free_margin, settings)
                log.info(
                    "%s signal=%s conf=%.2f | entryMargin=%.4f | notional=%.4f",
                    symbol,
                    signal.side,
                    signal.confidence,
                    plan.entry_margin,
                    plan.notional,
                )

                # TODO: calculate quantity from notional/price, validate step size,
                # place entry order, then immediately place reduce-only SL/TP.

            time.sleep(settings.loop_seconds)
        except KeyboardInterrupt:
            log.info("Bot stopped by user")
            break
        except Exception as exc:
            log.exception("Runtime error: %s", exc)
            time.sleep(10)

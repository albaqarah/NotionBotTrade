from __future__ import annotations

import hashlib
import hmac
import json
import time
import urllib.parse
import urllib.request
from typing import Any, Dict, Optional

from .config import Settings


class BinanceFuturesClient:
    """Minimal Binance USDT-M Futures REST client.

    DRY_RUN is enabled by default. Do not run live until you fully test everything.
    """

    def __init__(self, settings: Settings):
        self.settings = settings
        if settings.use_testnet:
            self.base_url = "https://testnet.binancefuture.com"
        else:
            self.base_url = "https://fapi.binance.com"

    def _sign(self, params: Dict[str, Any]) -> str:
        query = urllib.parse.urlencode(params, doseq=True)
        signature = hmac.new(
            self.settings.api_secret.encode(),
            query.encode(),
            hashlib.sha256,
        ).hexdigest()
        return query + "&signature=" + signature

    def _request(self, method: str, path: str, params: Optional[Dict[str, Any]] = None, signed: bool = False) -> Any:
        params = params or {}
        headers = {"X-MBX-APIKEY": self.settings.api_key}
        if signed:
            params["timestamp"] = int(time.time() * 1000)
            params.setdefault("recvWindow", 5000)
            query = self._sign(params)
        else:
            query = urllib.parse.urlencode(params, doseq=True)

        url = self.base_url + path
        data = None
        if method.upper() == "GET":
            if query:
                url += "?" + query
        else:
            data = query.encode()
            headers["Content-Type"] = "application/x-www-form-urlencoded"

        req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode()
            return json.loads(raw) if raw else {}

    def get_account(self) -> Dict[str, Any]:
        if self.settings.dry_run:
            return {
                "dryRun": True,
                "availableBalance": "1000.0",
                "totalWalletBalance": "1000.0",
            }
        return self._request("GET", "/fapi/v2/account", signed=True)

    def get_available_margin_usdt(self) -> float:
        account = self.get_account()
        # Binance futures account usually exposes availableBalance as string.
        value = account.get("availableBalance") or account.get("maxWithdrawAmount") or "0"
        return float(value)

    def set_leverage(self, symbol: str, leverage: int) -> Any:
        if self.settings.dry_run:
            return {"dryRun": True, "symbol": symbol, "leverage": leverage}
        return self._request("POST", "/fapi/v1/leverage", {"symbol": symbol, "leverage": leverage}, signed=True)

    def place_market_order(self, symbol: str, side: str, quantity: float, reduce_only: bool = False) -> Any:
        """side: BUY or SELL. quantity must respect Binance step size."""
        params = {
            "symbol": symbol,
            "side": side,
            "type": "MARKET",
            "quantity": quantity,
            "reduceOnly": "true" if reduce_only else "false",
        }
        if self.settings.dry_run:
            return {"dryRun": True, "order": params}
        return self._request("POST", "/fapi/v1/order", params, signed=True)

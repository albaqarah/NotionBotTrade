from __future__ import annotations

from dataclasses import dataclass
from .config import Settings, is_btc_eth


@dataclass
class PositionPlan:
    symbol: str
    side: str  # LONG or SHORT
    free_margin_usdt: float
    entry_margin: float
    notional: float
    leverage: int


def calc_entry_from_free_margin(symbol: str, side: str, free_margin_usdt: float, settings: Settings) -> PositionPlan:
    """User's final rule: every entry uses 10% of available/free futures margin."""
    entry_margin = free_margin_usdt * settings.entry_margin_pct
    notional = entry_margin * settings.leverage
    return PositionPlan(
        symbol=symbol,
        side=side,
        free_margin_usdt=free_margin_usdt,
        entry_margin=entry_margin,
        notional=notional,
        leverage=settings.leverage,
    )


def sl_far_from_liq(symbol: str, side: str, sl_price: float, liq_price: float, settings: Settings) -> bool:
    """Mandatory anti-liquidation buffer check.

    LONG: liquidation is below SL. Need (SL - liq) / SL >= buffer.
    SHORT: liquidation is above SL. Need (liq - SL) / SL >= buffer.
    """
    buffer = settings.min_sl_to_liq_btc_eth if is_btc_eth(symbol) else settings.min_sl_to_liq_alt
    side = side.upper()
    if sl_price <= 0 or liq_price <= 0:
        return False
    if side == "LONG":
        distance = (sl_price - liq_price) / sl_price
    elif side == "SHORT":
        distance = (liq_price - sl_price) / sl_price
    else:
        return False
    return distance >= buffer


def compute_placeholder_sl(entry_price: float, side: str, pct: float = 0.003) -> float:
    """Placeholder SL: 0.3% away from entry. Replace with ATR/order-book stop."""
    if side.upper() == "LONG":
        return entry_price * (1 - pct)
    if side.upper() == "SHORT":
        return entry_price * (1 + pct)
    raise ValueError("side must be LONG or SHORT")

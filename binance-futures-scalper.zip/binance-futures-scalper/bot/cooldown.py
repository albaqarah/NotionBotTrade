from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Dict

from .config import Settings, is_btc_eth


@dataclass
class CooldownState:
    until_ts: float = 0.0
    reason: str = ""
    sl_streak: int = 0


class CooldownManager:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.states: Dict[str, CooldownState] = {}

    def state(self, symbol: str) -> CooldownState:
        return self.states.setdefault(symbol, CooldownState())

    def active(self, symbol: str, now: float | None = None) -> bool:
        now = time.time() if now is None else now
        return now < self.state(symbol).until_ts

    def can_trade_strict(self, symbol: str, market_ok: bool, now: float | None = None) -> bool:
        """Strict cooldown: time must pass AND marketOK must be true."""
        now = time.time() if now is None else now
        st = self.state(symbol)
        if now < st.until_ts:
            return False
        if not market_ok:
            self.apply(symbol, "bad_market_extend", now=now)
            return False
        return True

    def apply(self, symbol: str, reason: str, now: float | None = None) -> None:
        now = time.time() if now is None else now
        btceth = is_btc_eth(symbol)
        st = self.state(symbol)

        if reason == "tp":
            cd = self.settings.cd_tp_btc_eth if btceth else self.settings.cd_tp_alt
            st.sl_streak = 0
        elif reason == "sl":
            cd = self.settings.cd_sl_btc_eth if btceth else self.settings.cd_sl_alt
            st.sl_streak += 1
            if st.sl_streak >= 2:
                cd = max(cd, 600 if btceth else 900)
        elif reason in {"emergency", "near_liq"}:
            cd = self.settings.cd_emergency_btc_eth if btceth else self.settings.cd_emergency_alt
        elif reason == "bad_market_extend":
            cd = self.settings.cd_bad_market_extend_btc_eth if btceth else self.settings.cd_bad_market_extend_alt
        elif reason == "flip":
            cd = 30
        else:
            cd = 60

        st.until_ts = now + cd
        st.reason = reason

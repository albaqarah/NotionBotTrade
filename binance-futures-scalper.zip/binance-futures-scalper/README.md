# Binance Futures Scalping Bot Starter

Starter project for a Binance USDT-M Futures scalping bot, built from the strategy rules discussed in chat.

## Core rules implemented

- Exchange target: **Binance USDT-M Futures**
- Position mode: **one-way per symbol**
- Direction: **long + short**
- Leverage: **10x**
- Entry sizing: **10% of available/free futures margin on every entry**
- Cooldown: **strict cooldown** = timer must pass **and** market condition must be OK
- Execution: hybrid concept, **maker-first**, taker only when edge/confidence is strong
- Safety: stop loss / reduce-only / anti-liquidation checks are included as required gates

## Important warning

This is a starter scaffold, not a guaranteed profitable trading bot. Crypto futures trading with leverage is high risk. Run in **DRY_RUN** or Binance testnet first. Never paste API keys into chat or commit `.env` to GitHub.

## Quick start

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
python -m bot
```

By default, `DRY_RUN=true`, so the bot will not send live orders.

## Upload to GitHub

After downloading this ZIP and extracting it:

```bash
git init
git add .
git commit -m "Initial Binance futures scalper scaffold"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

## Run on VPS

```bash
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git
cd YOUR_REPO
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
python -m bot
```

Recommended 24/7 process options:

```bash
# simple
sudo apt update && sudo apt install tmux -y
tmux new -s trading-bot
python -m bot
# detach: Ctrl+b then d
# reattach: tmux attach -t trading-bot
```

## Project structure

```text
bot/
  __main__.py
  config.py
  cooldown.py
  exchange_binance.py
  logger.py
  main.py
  market.py
  risk.py
  strategy.py
.env.example
.gitignore
requirements.txt
SKILL.md
```

## What you still need to implement/tune

1. Real websocket order book/trade data.
2. Real signal model, e.g. LightGBM/XGBoost outputting `long_confidence` and `short_confidence`.
3. Real liquidation price calculation from exchange position/account data.
4. Full bracket order handling for SL/TP.
5. Backtesting and paper trading.
